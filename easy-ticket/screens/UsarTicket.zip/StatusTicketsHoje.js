import React, { useState } from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useFocusEffect } from "@react-navigation/native";

export default function StatusTicketsHoje() {
  const [alunos, setAlunos] = useState([]);

  useFocusEffect(
    React.useCallback(() => {
      const carregarAlunos = async () => {
        try {
          const json = await AsyncStorage.getItem("alunos");
          if (json) setAlunos(JSON.parse(json));
          else setAlunos([]);
        } catch (e) {
          setAlunos([]);
        }
      };
      carregarAlunos();
    }, [])
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Status dos Tickets de Hoje</Text>
      <FlatList
        data={alunos}
        keyExtractor={(item) => item.matricula}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.itemText}>
              {item.nome} - {item.matricula} - {item.turma}
            </Text>
            {/* Adicione aqui o status do ticket se necessário */}
          </View>
        )}
        ListEmptyComponent={<Text style={styles.empty}>Nenhum aluno cadastrado.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f9f9f9" },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 20 },
  item: {
    padding: 10,
    backgroundColor: "#fff",
    borderRadius: 6,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: "#eee",
  },
  itemText: { fontSize: 14 },
  empty: { textAlign: "center", color: "#888", marginTop: 30 },
});